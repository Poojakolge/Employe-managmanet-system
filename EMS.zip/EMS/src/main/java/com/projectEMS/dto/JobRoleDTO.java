package com.projectEMS.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import com.projectEMS.entities.Department;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor(staticName="build")
@Data
public class JobRoleDTO {
	private int id;
	
	@NotEmpty(message="jobrole name cannot be null or empty")
	private String jobrole;
	
	@NotNull(message="Enter department id")
	private int departmentId;
    private Department department;
}
