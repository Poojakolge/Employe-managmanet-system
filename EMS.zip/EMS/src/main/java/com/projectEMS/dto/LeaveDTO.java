package com.projectEMS.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import com.projectEMS.entities.Employee;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor(staticName="build")
@Data
public class LeaveDTO {
	private int id;
	
	@NotNull
	private int employeeId;
	private Employee employee;
	
	@NotEmpty(message="Enter reason")
	private String reason;
	
	@NotBlank (message="Enter date")
	private Long fromdate;
	
	@NotBlank (message="Enter date")
	private Long todate;
	
	@NotNull(message="Enter status")
	private String status;


}
