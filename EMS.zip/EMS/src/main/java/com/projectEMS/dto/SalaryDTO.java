package com.projectEMS.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.projectEMS.entities.JobRole;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor(staticName="build")
@Data
public class SalaryDTO {
	private int id;
	
	@NotNull
	private int jobRoleId;
    private JobRole jobRole;
	
	@NotEmpty
	private Long amountmonthly;
	
	@NotEmpty
	private Long amountannual;

}
