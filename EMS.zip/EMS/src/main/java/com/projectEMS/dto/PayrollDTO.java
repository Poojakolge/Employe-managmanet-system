/*
 * package com.projectEMS.dto;
 * 
 * public class PayrollDTO {
 * 
 * }
 */