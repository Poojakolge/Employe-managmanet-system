package com.projectEMS.converter;

import org.springframework.stereotype.Component;
import com.projectEMS.dto.JobRoleDTO;
import com.projectEMS.entities.Department;
import com.projectEMS.entities.JobRole;



@Component
public class JobRoleConverter {
	public JobRoleDTO entityToDto(JobRole jobRole) {
		JobRoleDTO jobRoleDTO = new JobRoleDTO();
		jobRoleDTO.setId(jobRole.getId());
		jobRoleDTO.setJobrole(jobRole.getJobrole());
		jobRoleDTO.setDepartmentId(jobRole.getDepartment().getId());
        return jobRoleDTO;
    }

    public JobRole dtoToEntity(JobRoleDTO jobRoleDTO) {
    	JobRole jobRole = new JobRole();
    	jobRole.setId(jobRoleDTO.getId());
    	jobRole.setJobrole(jobRoleDTO.getJobrole());
    	// Set department using the departmentId
    	Department department=new Department();
    	department.setId(jobRoleDTO.getDepartmentId());
    	jobRole.setDepartment(department);
        return jobRole;
    }

	

}
