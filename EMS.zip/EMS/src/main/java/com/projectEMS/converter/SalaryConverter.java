package com.projectEMS.converter;

import org.springframework.stereotype.Component;
import com.projectEMS.dto.SalaryDTO;
import com.projectEMS.entities.JobRole;
import com.projectEMS.entities.Salary;

@Component
public class SalaryConverter {
	public SalaryDTO entityToDto(Salary salary) {
        SalaryDTO salaryDTO = new SalaryDTO();
        salaryDTO.setId(salary.getId());
        salaryDTO.setJobRoleId(salary.getJobRole().getId());
        salaryDTO.setAmountmonthly(salary.getAmountmonthly());
        salaryDTO.setAmountannual(salary.getAmountannual());
        return salaryDTO;
    }

    public Salary dtoToEntity(SalaryDTO salaryDTO) {
        Salary salary = new Salary();
        salary.setId(salaryDTO.getId());
     
        //Set Jobrole using the jobroleId
    	JobRole jobRole=new JobRole();
    	jobRole.setId(salaryDTO.getJobRoleId());
    	
        salary.setAmountmonthly(salaryDTO.getAmountmonthly());
        salary.setAmountannual(salaryDTO.getAmountannual());
        return salary;
    }

}
