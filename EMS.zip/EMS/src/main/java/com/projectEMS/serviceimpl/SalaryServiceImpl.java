package com.projectEMS.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.projectEMS.converter.SalaryConverter;
import com.projectEMS.dao.SalaryRepository;
import com.projectEMS.dto.SalaryDTO;
import com.projectEMS.entities.Salary;
import com.projectEMS.service.SalaryService;

@Component
public class SalaryServiceImpl implements SalaryService {
	
	@Autowired
    private SalaryRepository salaryRepository;

    @Autowired
    private SalaryConverter salaryConverter;

    @Override
    public SalaryDTO getSalaryById(int id) {
        Salary salary = salaryRepository.findById(id).orElse(null);
        return salaryConverter.entityToDto(salary);
    }

    @Override
    public SalaryDTO createSalary(SalaryDTO salaryDTO) {
        Salary salary = salaryConverter.dtoToEntity(salaryDTO);
        salary = salaryRepository.save(salary);
        return salaryConverter.entityToDto(salary);
    }

    @Override
    public SalaryDTO updateSalary(SalaryDTO salaryDTO) {
        Salary salary = salaryConverter.dtoToEntity(salaryDTO);
        salary.setId(salaryDTO.getId());
        salary = salaryRepository.save(salary);
        return salaryConverter.entityToDto(salary);
    }

    @Override
    public void deleteSalary(int id) {
        salaryRepository.deleteById(id);
    }
}
