package com.projectEMS.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.projectEMS.converter.LeaveConverter;
import com.projectEMS.dao.LeaveRepository;
import com.projectEMS.dto.LeaveDTO;
import com.projectEMS.entities.Leave;
import com.projectEMS.service.LeaveService;

@Component
public class LeaveServiceImpl implements LeaveService{

	@Autowired
	private final LeaveRepository leaveRepository;
    private final LeaveConverter leaveConverter;

    public LeaveServiceImpl(LeaveRepository leaveRepository, LeaveConverter leaveConverter) {
        this.leaveRepository = leaveRepository;
        this. leaveConverter = leaveConverter;
    }

    @Override
    public LeaveDTO createLeave(LeaveDTO leaveDTO) {
        Leave leave = leaveConverter.convertToLeaveEntity(leaveDTO);
        leave = leaveRepository.save(leave);
        return leaveConverter.convertToLeaveDTO(leave);
    }

    @Override
    public LeaveDTO getLeaveById(int id) {
        Optional<Leave> leave = leaveRepository.findById(id);
        return leave.map(leaveConverter::convertToLeaveDTO).orElse(null);
    }

    @Override
    public LeaveDTO updateLeave(int id, LeaveDTO leaveDTO) {
        Leave leave = leaveConverter.convertToLeaveEntity(leaveDTO);
        leave.setId(id);
        leave = leaveRepository.save(leave);
        return leaveConverter.convertToLeaveDTO(leave);
    }

    @Override
    public String deleteLeave(int id) {
        leaveRepository.deleteById(id);
        return "Leave with ID " + id + " has been deleted successfully.";
    }

    @Override
    public List<LeaveDTO> getAllLeaves() {
        List<Leave> leaves = leaveRepository.findAll();
        return leaves.stream().map(leaveConverter::convertToLeaveDTO).collect(Collectors.toList());
    }

}
