package com.projectEMS.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.projectEMS.converter.JobRoleConverter;
import com.projectEMS.dao.JobRoleRepository;
import com.projectEMS.dto.JobRoleDTO;
import com.projectEMS.entities.JobRole;
import com.projectEMS.service.JobRoleService;

@Component
public class JobRoleImpl implements JobRoleService {

	 @Autowired
	private final JobRoleRepository jobRoleRepository;
    private final JobRoleConverter jobRoleConverter;

    public JobRoleImpl(JobRoleRepository jobRoleRepository, JobRoleConverter jobRoleConverter) {
        this.jobRoleRepository = jobRoleRepository;
        this.jobRoleConverter = jobRoleConverter;
    }

    @Override
    public JobRoleDTO getJobRoleById(int id) {
    	JobRole jobRole = jobRoleRepository.findById(id).orElse(null);
        return jobRoleConverter.entityToDto(jobRole);
    }

    @Override
    public List<JobRoleDTO> getAllJobRoles() {
        List<JobRole> jobRoles = jobRoleRepository.findAll();
        return jobRoles.stream()
            .map(jobRoleConverter::entityToDto)
            .collect(Collectors.toList());
    }

    @Override
    public JobRoleDTO createJobRole(JobRoleDTO jobRoleDTO) {
    	JobRole jobRole = jobRoleConverter.dtoToEntity(jobRoleDTO);
    	jobRole = jobRoleRepository.save(jobRole);
        return jobRoleConverter.entityToDto(jobRole);
    }

    @Override
    public JobRoleDTO updateJobRole(int id, JobRoleDTO jobRoleDTO) {
    	JobRole jobRole = jobRoleConverter.dtoToEntity(jobRoleDTO);
    	jobRole.setId(id);
    	jobRole = jobRoleRepository.save(jobRole);
        return jobRoleConverter.entityToDto(jobRole);
    }

    @Override
    public String deleteJobRole(int id) {
        if (jobRoleRepository.existsById(id)) {
        	jobRoleRepository.deleteById(id);
            return "deleted";
        }else {
        return "not found";
        }
    }

}
