/*
 * package com.projectEMS.dao;
 * 
 * public interface PayrollRepository {
 * 
 * }
 */
