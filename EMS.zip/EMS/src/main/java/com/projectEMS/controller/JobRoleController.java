package com.projectEMS.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.projectEMS.dto.JobRoleDTO;
import com.projectEMS.service.JobRoleService;


@RestController
@RequestMapping("/api/jobroles")
public class JobRoleController {
	
	@Autowired
    private JobRoleService jobRoleService;

    @GetMapping("/jobRoles")
    public List<JobRoleDTO> getAllJobRoles() {
        List<JobRoleDTO> jobRoleDTOs = jobRoleService.getAllJobRoles();
        return jobRoleDTOs;
    }

    @GetMapping("/jobRoles/{id}")
    public ResponseEntity<JobRoleDTO> getJobRole(@PathVariable int id) {
    	JobRoleDTO jobRoleDTO = jobRoleService.getJobRoleById(id);
        if (jobRoleDTO != null) {
            return ResponseEntity.ok(jobRoleDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/jobRoles")
    public ResponseEntity<JobRoleDTO> addJobRole(@RequestBody JobRoleDTO jobRoleDTO) {
    	JobRoleDTO createdJobRole = jobRoleService.createJobRole(jobRoleDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdJobRole);
    }

    @PutMapping("/jobRoles/{id}")
    public ResponseEntity<JobRoleDTO> updateJobRole(@RequestBody JobRoleDTO jobRoleDTO, @PathVariable int id) {
    	JobRoleDTO updatedJobRole = jobRoleService.updateJobRole(id,jobRoleDTO);
        if (updatedJobRole != null) {
            return ResponseEntity.ok(updatedJobRole);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/jobRoles/{id}")
    public ResponseEntity<Void> deleteJobRoleByID(@PathVariable int id) {
        String result = jobRoleService.deleteJobRole(id);
        if (result.equals("deleted")) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
