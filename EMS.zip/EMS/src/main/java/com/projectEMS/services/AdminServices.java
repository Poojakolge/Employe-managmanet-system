package com.projectEMS.services;

import java.util.List;
import com.projectEMS.dto.AdminDTO;

public class AdminServices {
	
    public AdminDTO createAdmin(AdminDTO adminDTO) {
        
        return null; 
    }

    public AdminDTO getAdminById(int id) {
     
        return null; 
    }

    public AdminDTO updateAdmin(int id, AdminDTO adminDTO) {
       
        return null; 
    }

    public String deleteAdmin(int id) {
      
        return "Admin with ID " + id + " has been deleted successfully.";
    }

    public List<AdminDTO> getAllAdmins() {
       
        return null; 
    }

}
