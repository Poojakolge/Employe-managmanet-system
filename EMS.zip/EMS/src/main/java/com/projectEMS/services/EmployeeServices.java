package com.projectEMS.services;

import java.util.List;

import com.projectEMS.dto.EmployeeDTO;
import com.projectEMS.service.EmployeeService;

public class EmployeeServices implements EmployeeService{

	@Override
	public EmployeeDTO getEmployeeById(int id) {
		return null;
	}

	@Override
	public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
		return null;
	}

	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO employeeDTO) {
		return null;
	}

	@Override
	public void deleteEmployee(int id) {
		
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		return null;
	}

	

}
