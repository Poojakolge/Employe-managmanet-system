package com.projectEMS.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import com.projectEMS.converter.LeaveConverter;
import com.projectEMS.dao.LeaveRepository;
import com.projectEMS.dto.LeaveDTO;
import com.projectEMS.entities.Leave;

public class LeaveServices {
	
	@Autowired
    private LeaveRepository leaveRepository;

    @Autowired
    private LeaveConverter leaveConverter;

    public LeaveDTO getLeaveById(int id) {
        Optional<Leave> leave = leaveRepository.findById(id);
        return leave.map(leaveConverter::convertToLeaveDTO).orElse(null);
    }

    public LeaveDTO createLeave(LeaveDTO leaveDTO) {
        Leave leave = leaveConverter.convertToLeaveEntity(leaveDTO);
        leave = leaveRepository.save(leave);
        return leaveConverter.convertToLeaveDTO(leave);
    }

    public LeaveDTO updateLeave(int id, LeaveDTO leaveDTO) {
        Leave leave = leaveConverter.convertToLeaveEntity(leaveDTO);
        leave.setId(id);
        leave = leaveRepository.save(leave);
        return leaveConverter.convertToLeaveDTO(leave);
    }

    public String deleteLeave(int id) {
        leaveRepository.deleteById(id);
        return "Leave with ID " + id + " has been deleted successfully.";
    }

    public List<LeaveDTO> getAllLeaves() {
        List<Leave> leaves = leaveRepository.findAll();
        return leaves.stream().map(leaveConverter::convertToLeaveDTO).collect(Collectors.toList());
    }
}
