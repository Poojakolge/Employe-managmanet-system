package com.projectEMS.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.projectEMS.converter.DepartmentConverter;
import com.projectEMS.dao.DepartmentRepository;
import com.projectEMS.dto.DepartmentDTO;
import com.projectEMS.entities.Department;

public class DepartmentServices {
	 
	@Autowired
	private final DepartmentRepository departmentRepository;
	private final DepartmentConverter departmentConverter;

	    
	    public DepartmentServices(DepartmentRepository departmentRepository, DepartmentConverter departmentConverter) {
	        this.departmentRepository = departmentRepository;
	        this.departmentConverter = departmentConverter;
	    }

	    public DepartmentDTO getDepartmentById(int id) {
	        Department department = departmentRepository.findById(id).orElse(null);
	        return departmentConverter.entityToDto(department);
	    }

	    public DepartmentDTO createDepartment(DepartmentDTO departmentDTO) {
	        Department department = departmentConverter.dtoToEntity(departmentDTO);
	        department = departmentRepository.save(department);
	        return departmentConverter.entityToDto(department);
	    }

	    public DepartmentDTO updateDepartment(int id, DepartmentDTO departmentDTO) {
	        Department department = departmentConverter.dtoToEntity(departmentDTO);
	        department.setId(id);
	        department = departmentRepository.save(department);
	        return departmentConverter.entityToDto(department);
	    }

	    public void deleteDepartment(int id) {
	        departmentRepository.deleteById(id);
	    }

	    public List<DepartmentDTO> getAllDepartments() {
	        List<Department> departments = departmentRepository.findAll();
	        return departments.stream()
	                .map(departmentConverter::entityToDto)
	                .collect(Collectors.toList());
	    }
}
