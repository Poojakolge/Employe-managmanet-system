package com.projectEMS.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.projectEMS.dao.UserRepository;
import com.projectEMS.entities.User;

public class UserServices {
	@Autowired
    private  UserRepository userRepository ;
    
    public UserServices(UserRepository userRepository) 
    {
        this.userRepository = userRepository;
    }
    public User saveUser(User user)
    {
        return userRepository.save(user);
    }

    public List<User> getAllUser() 
    {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(int userId) 
    {
        return userRepository.findById(userId);
    }

    public User updateUser(User user) 
    {
        return userRepository.save(user);
    }
}
