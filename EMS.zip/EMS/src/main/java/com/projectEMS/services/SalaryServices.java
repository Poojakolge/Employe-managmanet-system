package com.projectEMS.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.projectEMS.converter.SalaryConverter;
import com.projectEMS.dao.SalaryRepository;
import com.projectEMS.dto.SalaryDTO;
import com.projectEMS.entities.Salary;

public class SalaryServices {
	 @Autowired
	    private SalaryRepository salaryRepository;

	    @Autowired
	    private SalaryConverter salaryConverter;

	    public SalaryDTO getSalaryById(int id) {
	    	Salary salary = salaryRepository.findById(id).orElse(null);
	        return salaryConverter.entityToDto(salary);
	    }

	    public SalaryDTO createSalary(SalaryDTO salaryDTO) {
	        Salary salary = salaryConverter.dtoToEntity(salaryDTO);
	        salary = salaryRepository.save(salary);
	        return salaryConverter.entityToDto(salary);
	    }

	    public SalaryDTO updateSalary(SalaryDTO salaryDTO) {
	        Salary salary = salaryConverter.dtoToEntity(salaryDTO);
	        salary.setId(salaryDTO.getId());
	        salary = salaryRepository.save(salary);
	        return salaryConverter.entityToDto(salary);
	    }

	    public void deleteSalary(int id) {
	        salaryRepository.deleteById(id);
	    }

}
