package com.projectEMS.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.projectEMS.converter.JobRoleConverter;
import com.projectEMS.dao.JobRoleRepository;
import com.projectEMS.dto.JobRoleDTO;
import com.projectEMS.entities.JobRole;

public class JobRoleServices {
	
	 @Autowired
	private final JobRoleRepository jobRoleRepository;
    private final JobRoleConverter jobRoleConverter;

   
    public JobRoleServices(JobRoleRepository jobRoleRepository, JobRoleConverter jobRoleConverter) {
        this.jobRoleRepository = jobRoleRepository;
        this.jobRoleConverter = jobRoleConverter;
    }

    public JobRoleDTO getJobRoleById(int id) {
    	JobRole jobRole = jobRoleRepository.findById(id).orElse(null);
        return jobRoleConverter.entityToDto(jobRole);
    }

    public JobRoleDTO createJobRole(JobRoleDTO jobRoleDTO) {
    	JobRole jobRole = jobRoleConverter.dtoToEntity(jobRoleDTO);
    	jobRole = jobRoleRepository.save(jobRole);
        return jobRoleConverter.entityToDto(jobRole);
    }

    public JobRoleDTO updateJobRole(int id, JobRoleDTO jobRoleDTO) {
    	JobRole jobRole = jobRoleConverter.dtoToEntity(jobRoleDTO);
    	jobRole.setId(id);
    	jobRole = jobRoleRepository.save(jobRole);
        return jobRoleConverter.entityToDto(jobRole);
    }

    public void deleteJobRole(int id) {
    	jobRoleRepository.deleteById(id);
    }

    public List<JobRoleDTO> getAllJobRoles() {
        List<JobRole> departments = jobRoleRepository.findAll();
        return departments.stream()
                .map(jobRoleConverter::entityToDto)
                .collect(Collectors.toList());
    }

}
