package com.projectEMS.entities;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Employee_Details")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Employee_ID")
	private int id;
	
	@Column(name="FirstName")
	private String firstname;
	
	@Column(name="LastName")
	private String lastname;
	
	@Column(name="Emp_Email")
	private String email;
	
	@Column(name="Emp_Gender")
	private String gender;
	
	@Column(name="Emp_Age")
	private int age;
	
	@ManyToOne
    @JoinColumn(name="department_id")
    private Department department;
	
	@ManyToOne
    @JoinColumn(name="jobRole_id")
    private JobRole jobRole;
	

}
