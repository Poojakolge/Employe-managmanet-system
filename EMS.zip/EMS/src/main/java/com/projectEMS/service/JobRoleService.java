package com.projectEMS.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.projectEMS.dto.JobRoleDTO;

@Service
public interface JobRoleService {
	JobRoleDTO createJobRole(JobRoleDTO jobRoleDTO);
	JobRoleDTO getJobRoleById(int id);
	JobRoleDTO updateJobRole(int id, JobRoleDTO jobRoleDTO);
    String deleteJobRole(int id);
    List<JobRoleDTO> getAllJobRoles();
	
}
