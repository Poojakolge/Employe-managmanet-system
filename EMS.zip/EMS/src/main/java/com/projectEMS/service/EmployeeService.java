package com.projectEMS.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.projectEMS.dto.EmployeeDTO;

@Service
public interface EmployeeService {
    EmployeeDTO getEmployeeById(int id);
    EmployeeDTO createEmployee(EmployeeDTO employeeDTO);
    EmployeeDTO updateEmployee(EmployeeDTO employeeDTO);
    void deleteEmployee(int id);
    List<EmployeeDTO> getAllEmployees();


}
