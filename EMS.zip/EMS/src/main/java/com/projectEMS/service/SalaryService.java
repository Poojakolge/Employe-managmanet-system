package com.projectEMS.service;

import org.springframework.stereotype.Service;
import com.projectEMS.dto.SalaryDTO;

@Service
public interface SalaryService {
	SalaryDTO getSalaryById(int id);
    SalaryDTO createSalary(SalaryDTO salaryDTO);
    SalaryDTO updateSalary(SalaryDTO salaryDTO);
    void deleteSalary(int id);

}
